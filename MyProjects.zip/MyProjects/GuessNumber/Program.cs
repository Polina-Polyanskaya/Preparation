﻿using GuessNumber;

var game = new GuessNumberGame(guessingPlayer: GuessingPlayer.Machine);
game.Start();   

