﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HangmanGame
{
    public enum GameStatus
    {
        Won,
        Lost,
        InProgress,
        NotStarted
    }
}
